//
//  MovieDetailView.swift
//  Husqvarna assignment
//
//  Created by mac_admin on 03/08/23.
//

import SwiftUI

struct MovieDetailView: View {
    var movie: MovieData

    var body: some View {
        List{
            MovieImage(urlString: movie.backdrop_path ?? "")
            Text(movie.overview ?? "")
        }
        .navigationBarTitle(movie.title ?? "")
    }
}



