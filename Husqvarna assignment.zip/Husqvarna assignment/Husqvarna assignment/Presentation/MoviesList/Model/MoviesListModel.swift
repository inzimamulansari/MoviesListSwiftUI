//
//  MoviesListModel.swift
//  Husqvarna assignment
//
//  Created by mac_admin on 03/08/23.
//

import Foundation
import SwiftUI

struct MovieResult: Codable {
    let results: [MovieData]
}

struct MovieData: Codable,Identifiable  {
    let id: Int?
    let backdrop_path: String?
    let overview: String?
    let title: String?
}
