//
//  MoviesListView.swift
//  Husqvarna assignment
//
//  Created by mac_admin on 03/08/23.
//

import SwiftUI

struct MoviesListView: View {
        @StateObject private var MoviesListVM = MoviesListViewModel()
    
        var body: some View {
            NavigationView {
                List(MoviesListVM.movies) { movie in
                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                        MovieImage(urlString: movie.backdrop_path ?? "")
                    }
                }
                .navigationBarTitle("Popular Movies")
                .onAppear {
                    MoviesListVM.fetchMovies()
                }
            }
        }
    
}


struct MovieImage: View {
    let urlString: String

    var body: some View {
        if let url = URL(string: "https://image.tmdb.org/t/p/w500\(urlString)") {
            AsyncImage(url: url)
                .aspectRatio(contentMode: .fit)
                .frame(height: 200)
                .cornerRadius(10)
                .padding(10)
        }
    }
}
