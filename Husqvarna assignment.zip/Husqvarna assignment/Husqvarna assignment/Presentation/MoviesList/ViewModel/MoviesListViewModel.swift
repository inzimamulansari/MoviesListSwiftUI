//
//  MoviesListViewModel.swift
//  Husqvarna assignment
//
//  Created by mac_admin on 03/08/23.
//

import SwiftUI

class MoviesListViewModel: ObservableObject {
    @Published var movies: [MovieData] = []
    var moviesCount: Int?  = 20
    
     func fetchMovies() {
        guard let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=ea34cc940c8b6955875287c62a391e6e") else {
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(MovieResult.self, from: data)
                    DispatchQueue.main.async {
                        self.movies = result.results.map { MovieData(id: $0.id, backdrop_path: $0.backdrop_path, overview: $0.overview, title: $0.title) }
                        self.moviesCount = self.movies.count
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }
}
