//
//  Husqvarna_assignmentApp.swift
//  Husqvarna assignment
//
//  Created by mac_admin on 30/07/23.
//

import SwiftUI

@main
struct Husqvarna_assignmentApp: App {
    var body: some Scene {
        WindowGroup {
            MoviesListView()
        }
    }
}
